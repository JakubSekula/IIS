<?php

/******************************************************************************
 * Projekt: Hotel: rezervace a správa ubytování                               *
 * Předmět: IIS - Informační systémy - FIT VUT v Brně                         *
 * Rok:     2020/2021                                                         *
 * Tým:     xsekul01, varianta 2                                              *
 * Autoři:                                                                    *
 *          Jakub Sekula   (xsekul01) - xsekul01@stud.fit.vutbr.cz            *
 *          Lukáš Perina   (xperin11) - xperin11@stud.fit.vutbr.cz            *
 *			Martin Fekete  (xfeket00) - xfeket00@stud.fit.vutbr.cz            *
 ******************************************************************************/

?>

<?php
    include_once("include.php");
    sessionTimeout();
    checkRights(4);
    echo "<body onload=\"returnBack()\">";
    printHTMLheader("Admin page");
    printHeader();
?>
    <div class="content">
        <h1> You probably didnt want to enter that :(</h1>
        <h6> Redirecting to index page...</h6>
    <?php
    // after displaying error message return to index
    echo "<script>";
    echo "function returnBack(){";
    echo "setTimeout(function(){ window.location.replace(\"index.php\"); }, 1000);";
    echo "}</script>";
    ?>
    </div>
</body>